/*
 * proj2.cpp
 *
 *  Created on: Jan 28, 2020
 *      Author: joshuahsin
 */

#include "LLQueue.hpp"
#include <iostream>

#include <vector>

void countPaths(const std::vector< std::vector <unsigned> > & friends, unsigned start
		, std::vector<unsigned> & pathLengths, std::vector<unsigned> & numShortestPaths)
{
	numShortestPaths.size();
	std::cout << "hi" << std::endl;
	std::vector<bool> discovered;		//discovered
	for(int i = 0; i < friends.size(); i++){
		if(i != start){
			discovered.push_back(false);
		}
		else{
			discovered.push_back(true);
		}
	}//correct
	LLQueue<int> * QueueList;
	QueueList = new LLQueue<int>[friends.size()];	//L
	LLQueue<int> emptyQueue;
	emptyQueue.enqueue(start);
	QueueList[0] = emptyQueue;
	unsigned * distpaths;
	distpaths = new unsigned[friends.size()];
	distpaths[start] = 0;
	for(int i = 0; i < friends.size();i++){
		if(i == start){
			distpaths[i] = 0;
		}
		else{
			distpaths[i] = 100;
		}
	}
	unsigned * numDiffShortestPaths;
	numDiffShortestPaths =  new unsigned[friends.size()];
	for(int i = 0; i < friends.size();i++){
		if(i == start){
			numDiffShortestPaths[i] = 1;
		}
		else{
			numDiffShortestPaths[i] = 0;
		}
	}
	//std::cout << "front" << QueueList[0].front() << std::endl;
	int i = 0;
	while(!QueueList[i].isEmpty()){
		LLQueue<int> emptyQueue2;
		QueueList[i+1] = emptyQueue2;
		int sizeQueueList = QueueList[i].size();
		std::cout << "sizeQueueList" << sizeQueueList << std::endl;
		for(int j = 0; j < sizeQueueList; j++){
			unsigned temp = QueueList[i].front();
			std::cout << "temp" << temp << "i" << i << std::endl;
			QueueList[i].dequeue();
			//int edges = friends[temp].size();
			for(int k = 0; k < friends[temp].size(); k++){
				std::cout << "a " << numDiffShortestPaths[temp]<< std::endl;
				std::cout << "k " << k << " "<< numDiffShortestPaths[friends[temp][k]] << std::endl;
				if(distpaths[friends[temp][k]] > distpaths[temp] + 1){
					distpaths[friends[temp][k]] = distpaths[temp] + 1;
					numDiffShortestPaths[friends[temp][k]] = numDiffShortestPaths[temp];
					std::cout << "c" << std::endl;
				}
				else if(distpaths[friends[temp][k]] == distpaths[temp] + 1){
					numDiffShortestPaths[friends[temp][k]] += numDiffShortestPaths[temp];
					std::cout << "d" << std::endl;
				}
				if(discovered[friends[temp][k]] == false){
					discovered[friends[temp][k]] = true;
					QueueList[i+1].enqueue(friends[temp][k]);
				}
			}
			QueueList[i].enqueue(temp);
		}
		i = i + 1;
	}
	std::cout << i << std::endl;

	int count = 0;
	for(int j = 0; j < i; j++){
		int length = QueueList[j].size();
		for(int k = 0; k < length; k++){
			std::cout << "front" << QueueList[j].front() << " " << j << std::endl;
			unsigned temp = QueueList[j].front();
			QueueList[j].dequeue();
			pathLengths[temp] = j;
			count += 1;
			QueueList[j].enqueue(temp);
		}
	}
	for(int j = 0; j < friends.size(); j++){
		numShortestPaths[j] = numDiffShortestPaths[j];
	}

	for(int j = 0; j < friends.size(); j++){
		std::cout << "pathlengths "<< j << " " << pathLengths[j] << std::endl;
	}

	for(int j = 0; j < friends.size(); j++){
		std::cout << "numshortestpaths "<< j << " " << numShortestPaths[j] << std::endl;
	}
}

int main(){
	std::vector<unsigned> a;
	a.push_back(1);

	std::vector<unsigned> b;
	b.push_back(0);
	b.push_back(2);
	b.push_back(3);

	std::vector<unsigned> c;
	c.push_back(1);
	c.push_back(4);

	std::vector<unsigned> d;
	d.push_back(1);
	d.push_back(4);

	std::vector<unsigned> e;
	e.push_back(2);
	e.push_back(3);
	e.push_back(5);

	std::vector<unsigned> f;
	f.push_back(4);

	std::vector< std::vector<unsigned> > g1;
	g1.push_back(a);
	g1.push_back(b);
	g1.push_back(c);
	g1.push_back(d);
	g1.push_back(e);
	g1.push_back(f);
	std::vector<unsigned> pathLengths(6);
	std::vector<unsigned> numShortestPaths(6);

	countPaths(g1, 0, pathLengths, numShortestPaths);

	return 0;
}
