#Joshua Hsin #13651420
README.txt

Run files in same location as DEV files.

First, run assignment3.py. This will create the inverted index for the search engine, sorted in files alphabetically, with an additional extra.txt file for words starting with special characters.

Next, run assignment3_query.py, which makes a key_dictionary with document numbers matching urls of files, waits for user to start the engine, then takes queries, matching to the top 20 urls.

When done is printed, enter startMyEngine to start search engine, then enter queries.