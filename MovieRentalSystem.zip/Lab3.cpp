/*
 * Lab3.cpp
 *
 *  Created on: Nov 12, 2019
 *      Author: Michael Vo #31082403, Joshua Hsin #13651420
 */


#include <iostream>
using namespace std;

#include "MovieManager.hpp"




int main() {
	int totalMovies = 0;
	MovieManager Example(totalMovies);

	Example.run();

	return 0;
}
