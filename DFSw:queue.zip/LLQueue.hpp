//============================================================================
// Name        : proj2schindler.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#ifndef __PROJ2_QUEUE_HPP
#define __PROJ2_QUEUE_HPP

#include "runtimeexcept.hpp"
#include <iostream>

class QueueEmptyException : public RuntimeException
{
public:
	QueueEmptyException(const std::string & err) : RuntimeException(err) {}
};


template<typename Object>
class LLQueue
{
private:
	struct node{
		Object data;
		node* next;
		node* previous;
	};
	node* prev;
	node* current;
	node* start;
	size_t count;
public:
	LLQueue();
	~LLQueue(){
		//delete * start;
		//delete prev;
		//delete current;
	}
	size_t size() const;
	bool isEmpty() const;

	Object & front();
	const Object & front() const;

	void enqueue(const Object & elem);

	void dequeue();
};

template<typename Object>
LLQueue<Object>::LLQueue()
{
	count = 0;
	node* n;
	n = new node;
	//n->data = nullptr;
	n->previous = nullptr;
	n->next = nullptr;
	start = n;
	current = n;
	prev = n;
	//prev->next = current;
}

template<typename Object>
size_t LLQueue<Object>::size() const
{
	return count;
}

template<typename Object>
bool LLQueue<Object>::isEmpty() const
{
	return (size() == 0);
}


template<typename Object>
Object & LLQueue<Object>::front()
{
	try{
		if( isEmpty() )
		{
			throw QueueEmptyException("Cannot return front from an empty list");
		}
	}
	catch(QueueEmptyException & e){
		std::cout << "Cannot return front from an empty list" << std::endl;
		exit(1);
	}
	//std::cout << "not" << start->data << std::endl;
	return start->data;
}

template<typename Object>
void LLQueue<Object>::enqueue(const Object & elem)
{
	//prev = current;
	node* n;
	n = new node;
	n->data = elem;
	//std::cout << "a" << std::endl;
	//n->previous = current;
	n->next = NULL;
	if(count == 0){
		start = n;
		current = n;
		prev->next = current;
		current->previous = prev;
	}
	if(count == 1){
		start = current; // add this line
		current = n;
		start->next = current;
		prev = start;
		current->previous = prev;
	}
	if(count > 1){
		prev = current;
		current = n;
		current->previous = prev;
		prev->next = current;
	}
	count += 1;
}

template<typename Object>
void LLQueue<Object>::dequeue()
{
	//std::cout << count << std::endl;
	try{
		if( isEmpty() )
		{
			throw QueueEmptyException("Cannot dequeue from an empty list");
		}
	}
	catch(QueueEmptyException & e){
		std::cout << "Cannot dequeue from an empty list" << std::endl;
		exit(1);
	}
	if (count > 2){
		start = start->next;
	}
	else if (count == 2){
		 node* n;
		 n = new node;
		 n -> next = current;
		 n -> previous = nullptr;
		 prev = n;
		 start = current;
	}
	else if (count == 1){
		node* n;
		n = new node;
		n->next = nullptr;
		n->previous = nullptr;
		start = n;
		current = n;
		prev -> next = current;
	}
	count -= 1;
}



#endif
